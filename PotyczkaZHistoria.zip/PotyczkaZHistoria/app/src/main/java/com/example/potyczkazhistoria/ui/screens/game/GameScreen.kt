package com.example.potyczkazhistoria.ui.screens.game

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import kotlin.random.Random

data class Question(
    val text: String,
    val answers: List<String>,
    val correctIndex: Int
)

@Composable
fun GameScreen(
    onGameFinished: (score: Int, correctAnswers: Int, wrongAnswers: Int) -> Unit
) {
    var playerHp by remember { mutableStateOf(100) }
    var score by remember { mutableStateOf(0) }
    var correct by remember { mutableStateOf(0) }
    var wrong by remember { mutableStateOf(0) }
    var questionIndex by remember { mutableStateOf(0) }

    val totalQuestions = 5

    val questions = listOf(
        Question("Kiedy był chrzest Polski?", listOf("966", "1025", "1410"), 0),
        Question("Bitwa pod Grunwaldem miała miejsce w:", listOf("1410", "966", "1939"), 0),
        Question("Konstytucja 3 maja została uchwalona w roku:", listOf("1791", "1918", "1569"), 0),
        Question("Powstanie Warszawskie wybuchło w:", listOf("1944", "1939", "1920"), 0),
        Question("Pierwszy król Polski koronowany w 1025 r. to:", listOf("Bolesław Chrobry", "Mieszko I", "Kazimierz Wielki"), 0)
    )

    var currentQuestion by remember { mutableStateOf(questions.random()) }
    var randomizedAnswers by remember { mutableStateOf(shuffleAnswers(currentQuestion)) }

    val scope = rememberCoroutineScope()
    val shakeOffset = remember { Animatable(0f) }

    fun loadNextQuestion() {
        if (questionIndex + 1 >= totalQuestions || playerHp <= 0 || wrong >= 3) {
            onGameFinished(score, correct, wrong)
        } else {
            questionIndex++
            currentQuestion = questions.random()
            randomizedAnswers = shuffleAnswers(currentQuestion)
        }
    }

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(Color(0xFFEDEDED))
                .offset { IntOffset(shakeOffset.value.roundToInt(), 0) }
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            LinearProgressIndicator(
                progress = { questionIndex.toFloat() / totalQuestions.toFloat() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
            )

            Spacer(Modifier.height(16.dp))
            Text("Punkty życia: $playerHp", style = MaterialTheme.typography.titleLarge)
            Text("Wynik: $score", style = MaterialTheme.typography.titleMedium)
            Text("Pytanie ${questionIndex + 1} z $totalQuestions")

            Spacer(Modifier.height(24.dp))
            Text(currentQuestion.text, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(16.dp))

            randomizedAnswers.forEach { answer ->
                Button(
                    onClick = {
                        if (answer == currentQuestion.answers[currentQuestion.correctIndex]) {
                            playerHp += 10
                            score += 10
                            correct++
                        } else {
                            playerHp -= 10
                            wrong++

                            scope.launch {
                                shakeOffset.snapTo(0f)
                                shakeOffset.animateTo(
                                    targetValue = 30f,
                                    animationSpec = tween(50)
                                )
                                shakeOffset.animateTo(
                                    targetValue = -30f,
                                    animationSpec = tween(50)
                                )
                                shakeOffset.animateTo(
                                    targetValue = 0f,
                                    animationSpec = tween(50)
                                )
                            }
                        }
                        loadNextQuestion()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Text(answer)
                }
            }
        }
    }
}

fun shuffleAnswers(question: Question): List<String> {
    return question.answers.shuffled(Random(System.currentTimeMillis()))
}
