package com.example.potyczkazhistoria.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface QuestionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(questions: List<QuestionEntity>)

    @Query("SELECT * FROM questions WHERE chapterId = :chapterId")
    suspend fun getQuestionsForChapter(chapterId: Int): List<QuestionEntity>

    @Query("DELETE FROM questions")
    suspend fun deleteAll()
}