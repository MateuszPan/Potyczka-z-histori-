package com.example.potyczkazhistoria.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object DatabaseSeeder {
    fun seed(database: AppDatabase) {
        val epochDao = database.epochDao()
        val chapterDao = database.chapterDao()
        val questionDao = database.questionDao()
        val answerDao = database.answerDao()

        CoroutineScope(Dispatchers.IO).launch {
            // Usuń stare dane (testowo)
            answerDao.deleteAll()
            questionDao.deleteAll()
            chapterDao.deleteAll()
            epochDao.deleteAll()

            // Wstawiamy epoki z jawnie podanymi id (dla prostoty seeda)
            val epochs = listOf(
                EpochEntity(id = 1, name = "Starożytność"),
                EpochEntity(id = 2, name = "Średniowiecze")
            )
            epochDao.insertAll(epochs)

            // Rozdziały (używamy pola 'title' zgodnie z ChapterEntity)
            val chapters = listOf(
                ChapterEntity(id = 1, title = "Cesarstwo Rzymskie", epochId = 1),
                ChapterEntity(id = 2, title = "Państwo Polskie", epochId = 2)
            )
            chapterDao.insertAll(chapters)

            // Pytania (pola: id, text, difficulty, chapterId)
            val questions = listOf(
                QuestionEntity(id = 1, text = "Kiedy założono Rzym?", difficulty = "Łatwy", chapterId = 1),
                QuestionEntity(id = 2, text = "Kiedy był chrzest Polski?", difficulty = "Łatwy", chapterId = 2)
            )
            questionDao.insertAll(questions)

            // Odpowiedzi (pola: id, text, isCorrect, questionId)
            val answers = listOf(
                AnswerEntity(id = 1, text = "753 p.n.e.", isCorrect = true, questionId = 1),
                AnswerEntity(id = 2, text = "476 n.e.", isCorrect = false, questionId = 1),
                AnswerEntity(id = 3, text = "1453 n.e.", isCorrect = false, questionId = 1),

                AnswerEntity(id = 4, text = "966 r.", isCorrect = true, questionId = 2),
                AnswerEntity(id = 5, text = "1025 r.", isCorrect = false, questionId = 2),
                AnswerEntity(id = 6, text = "1410 r.", isCorrect = false, questionId = 2)
            )
            answerDao.insertAll(answers)
        }
    }
}
