package com.example.potyczkazhistoria.ui.screens.summary

import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun SummaryScreen(
    score: Int,
    correctAnswers: Int,
    wrongAnswers: Int,
    onPlayAgain: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? ComponentActivity

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Podsumowanie gry", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(24.dp))

            Text("Twój wynik: $score punktów")
            Spacer(Modifier.height(8.dp))
            Text("Poprawne odpowiedzi: $correctAnswers")
            Spacer(Modifier.height(8.dp))
            Text("Błędne odpowiedzi: $wrongAnswers")
            Spacer(Modifier.height(24.dp))

            Button(onClick = onPlayAgain, modifier = Modifier.fillMaxWidth()) {
                Text("Zagraj ponownie")
            }
            Spacer(Modifier.height(8.dp))

            OutlinedButton(
                onClick = {
                    activity?.finish() // 🚀 zamyka całą aplikację
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Wyjdź z gry")
            }
        }
    }
}
