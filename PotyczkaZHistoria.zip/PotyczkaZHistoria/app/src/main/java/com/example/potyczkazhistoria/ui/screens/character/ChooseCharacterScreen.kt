package com.example.potyczkazhistoria.ui.screens.character

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ChooseCharacterScreen(onNavigateNext: () -> Unit) {
    Scaffold { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Wybierz swoją postać", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Button(onClick = onNavigateNext) { Text("Rycerz 1") }
                Button(onClick = onNavigateNext) { Text("Rycerz 2") }
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Button(onClick = onNavigateNext) { Text("Rycerka 1") }
                Button(onClick = onNavigateNext) { Text("Rycerka 2") }
            }
        }
    }
}
