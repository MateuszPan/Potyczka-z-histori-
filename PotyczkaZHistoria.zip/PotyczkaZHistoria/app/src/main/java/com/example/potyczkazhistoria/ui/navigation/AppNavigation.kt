package com.example.potyczkazhistoria.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.NavType
import androidx.navigation.navArgument
import com.example.potyczkazhistoria.ui.screens.welcome.WelcomeScreen
import com.example.potyczkazhistoria.ui.screens.character.ChooseCharacterScreen
import com.example.potyczkazhistoria.ui.screens.epoch.ChooseEpochScreenWithNav
import com.example.potyczkazhistoria.ui.screens.chapter.ChooseChapterScreen
import com.example.potyczkazhistoria.ui.screens.difficulty.ChooseDifficultyScreen
import com.example.potyczkazhistoria.ui.screens.game.GameScreen
import com.example.potyczkazhistoria.ui.screens.summary.SummaryScreen

@Composable
fun AppNavigation(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = "welcome"
    ) {
        composable("welcome") {
            WelcomeScreen(
                onNavigateNext = { navController.navigate("chooseCharacter") }
            )
        }

        composable("chooseCharacter") {
            ChooseCharacterScreen(
                onNavigateNext = { navController.navigate("chooseEpoch") }
            )
        }

        composable("chooseEpoch") {
            ChooseEpochScreenWithNav(
                onNavigateNext = { navController.navigate("chooseChapter") }
            )
        }

        composable("chooseChapter") {
            ChooseChapterScreen(
                onNavigateNext = { navController.navigate("chooseDifficulty") }
            )
        }

        composable("chooseDifficulty") {
            ChooseDifficultyScreen(
                onNavigateNext = { navController.navigate("game") }
            )
        }

        composable("game") {
            GameScreen(
                onGameFinished = { score, correct, wrong ->
                    navController.navigate("summary/$score/$correct/$wrong")
                }
            )
        }

        composable(
            route = "summary/{score}/{correct}/{wrong}",
            arguments = listOf(
                navArgument("score") { type = NavType.IntType },
                navArgument("correct") { type = NavType.IntType },
                navArgument("wrong") { type = NavType.IntType }
            )
        ) { backStackEntry ->
            val score = backStackEntry.arguments?.getInt("score") ?: 0
            val correct = backStackEntry.arguments?.getInt("correct") ?: 0
            val wrong = backStackEntry.arguments?.getInt("wrong") ?: 0

            SummaryScreen(
                score = score,
                correctAnswers = correct,
                wrongAnswers = wrong,
                onPlayAgain = {
                    navController.navigate("welcome") {
                        popUpTo("welcome") { inclusive = true }
                    }
                }
            )
        }
    }
}
