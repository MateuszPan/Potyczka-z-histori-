package com.example.potyczkazhistoria.ui.screens.epoch

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ChooseEpochScreenWithNav(onNavigateNext: () -> Unit) {
    Scaffold { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Wybierz epokę", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(24.dp))

            Button(onClick = onNavigateNext, modifier = Modifier.fillMaxWidth()) {
                Text("Starożytność")
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onNavigateNext, modifier = Modifier.fillMaxWidth()) {
                Text("Średniowiecze")
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onNavigateNext, modifier = Modifier.fillMaxWidth()) {
                Text("Renesans")
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onNavigateNext, modifier = Modifier.fillMaxWidth()) {
                Text("Oświecenie")
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onNavigateNext, modifier = Modifier.fillMaxWidth()) {
                Text("XX wiek")
            }
        }
    }
}
